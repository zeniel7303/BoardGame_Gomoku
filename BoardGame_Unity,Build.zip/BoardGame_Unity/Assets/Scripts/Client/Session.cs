﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;

using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using System.Text;
using System.Runtime.InteropServices; //관리되지않는 코드 (포인터 사용및 구조체를 시퀜셜하게 만들기위해)

public class Session
{
    public Socket mySocket;

    userInformation info = new userInformation();
    UserData userData = new UserData();
    SendChatting sendChattingData = new SendChatting();
    ReqUserListData reqUserListData = new ReqUserListData();
    ReqRoomListData reqRoomListData = new ReqRoomListData();
    CreateRoom createRoomData = new CreateRoom();
    DestroyRoom destroyRoomData = new DestroyRoom();
    JoinRoom joinRoomData = new JoinRoom();
    IsReady isReadyData = new IsReady();
    GomokuGrid gomokuGridData = new GomokuGrid();
    GomokuResult gomokuResultData = new GomokuResult();

    public bool isBlackStone;
    public int ptx;
    public int pty;

    public bool isBlackWin;

    public void Init(string _ip, int _port)
    {
        mySocket = new Socket(
            AddressFamily.InterNetwork,
            SocketType.Stream,
            ProtocolType.IP);

        mySocket.Connect(_ip, _port);
    }

    public void FailConnect()
    {

    }

    public void RecvUserInfo(byte[] data, string name)
    {
        userData.socket = BitConverter.ToInt32(data, 4);
        userData.userID = BitConverter.ToInt32(data, 8);
        userData.roomNum = BitConverter.ToInt32(data, 12);

        info.socket = BitConverter.ToInt32(data, 4);
        info.userID = BitConverter.ToInt32(data, 8);
        info.roomNum = BitConverter.ToInt32(data, 12);

        SendUserInfo(0, name);
    }

    public void SendUserInfo(int _cmd, string _name)
    {
        userData.cmd = 0;

        info.name = _name;
        userData.name = _name;

        userData.size = (ushort)Marshal.SizeOf(userData);

        byte[] sendData = new byte[userData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(userData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(userData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, userData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public void SendReqLobbyUserList(int pageNum)
    {
        reqUserListData.cmd = 7;
        reqUserListData.page = pageNum;
        reqUserListData.socket = info.socket;
        reqUserListData.size = (ushort)Marshal.SizeOf(reqUserListData);

        byte[] sendData = new byte[reqUserListData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(reqUserListData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(reqUserListData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, reqUserListData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public void SendReqRoomList(int pageNum)
    {
        reqRoomListData.cmd = 8;
        reqRoomListData.page = pageNum;
        reqRoomListData.socket = info.socket;
        reqRoomListData.size = (ushort)Marshal.SizeOf(reqRoomListData);

        byte[] sendData = new byte[reqRoomListData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(reqRoomListData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(reqRoomListData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, reqRoomListData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public void SendMessage(string _value)
    {
        sendChattingData.message = _value;
        sendChattingData.socket = info.socket;

        if (info.roomNum > 0)
        {
            sendChattingData.cmd = 2;
        }
        else
        {
            sendChattingData.cmd = 1;
        }

        sendChattingData.size = (ushort)Marshal.SizeOf(sendChattingData);

        byte[] sendData = new byte[sendChattingData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(sendChattingData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(sendChattingData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, sendChattingData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public byte[] RecvMessage(byte[] data)
    {
        return data;
    }

    public void SendCreateRoom()
    {
        createRoomData.cmd = 3;  
        createRoomData.socket = info.socket;
        createRoomData.size = (ushort)Marshal.SizeOf(createRoomData);

        byte[] sendData = new byte[createRoomData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(createRoomData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(createRoomData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, createRoomData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public bool RecvCreateRoom(byte[] data)
    {
        info.roomNum = BitConverter.ToInt32(data, 12);

        GameManager.Instance.user.SetRoom(info.roomNum);

        return true;
    }

    public void SendExitRoom()
    {
        destroyRoomData.cmd = 4;
        destroyRoomData.socket = info.socket;
        destroyRoomData.size = (ushort)Marshal.SizeOf(destroyRoomData);

        byte[] sendData = new byte[destroyRoomData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(destroyRoomData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(destroyRoomData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, destroyRoomData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public bool RecvExitRoom(byte[] data)
    {
        info.roomNum = BitConverter.ToInt32(data, 12);
        
        GameManager.Instance.user.SetRoom(info.roomNum);

        return true;
    }

    public void SendJoinRoom(int roomNum)
    {
        joinRoomData.cmd = 5;
        joinRoomData.roomNum = (ushort)roomNum;
        joinRoomData.socket = info.socket;
        joinRoomData.size = (ushort)Marshal.SizeOf(joinRoomData);

        byte[] sendData = new byte[joinRoomData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(joinRoomData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(joinRoomData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, joinRoomData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public bool RecvJoinRoom(byte[] data)
    {
        info.roomNum = BitConverter.ToInt32(data, 12);

        GameManager.Instance.user.SetRoom(info.roomNum);

        return true;
    }

    public void SendReady(bool value)
    {
        isReadyData.cmd = 6;
        isReadyData.socket = info.socket;
        isReadyData.isReady = value;
        isReadyData.size = (ushort)Marshal.SizeOf(isReadyData);

        byte[] sendData = new byte[isReadyData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(isReadyData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(isReadyData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, isReadyData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public void SendGomokuGrid(int x, int y, bool isBlack)
    {
        gomokuGridData.cmd = 100;
        gomokuGridData.socket = info.socket;
        gomokuGridData.px = x;
        gomokuGridData.py = y;
        gomokuGridData.isBlack = isBlack;
        gomokuGridData.size = (ushort)Marshal.SizeOf(gomokuGridData);

        byte[] sendData = new byte[gomokuGridData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(gomokuGridData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(gomokuGridData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, gomokuGridData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public void RecvGomokuGrid(byte[] data)
    {
        ptx = BitConverter.ToInt32(data, 8);
        pty = BitConverter.ToInt32(data, 12);

        isBlackStone = BitConverter.ToBoolean(data, 16);
    }

    public void SendGomokuResult(bool isBlack)
    {
        gomokuResultData.cmd = 101;
        gomokuResultData.socket = info.socket;
        gomokuResultData.isBlack = isBlack;
        gomokuResultData.size = (ushort)Marshal.SizeOf(gomokuResultData);

        byte[] sendData = new byte[gomokuResultData.size];

        IntPtr memPtr = IntPtr.Zero;

        try
        {
            // Allocate some unmanaged memory
            memPtr = Marshal.AllocHGlobal(gomokuResultData.size);

            // Copy struct to unmanaged memory
            Marshal.StructureToPtr(gomokuResultData, memPtr, true);

            // Copies to byte array
            Marshal.Copy(memPtr, sendData, 0, gomokuResultData.size);
        }
        finally
        {
            if (memPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(memPtr);
            }
        }

        mySocket.Send(sendData);
    }

    public void RecvGomokuResult(byte[] data)
    {
        isBlackWin = BitConverter.ToBoolean(data, 8);
    }
}
