﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Runtime.InteropServices;

using System.Net;
using System.Net.Sockets;

class SendingRoomStruct
{
    public bool isPlaying = false;
    public int index = 0;
    public int count = 0;
    public int complement = 2;
};

[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
class RoomStruct
{
    public SendingRoomStruct roomInfo;

    public List<userInformation> userInfo_inRoom;
}

[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
class PacketHeader
{
    public ushort size;
    public ushort cmd;
    public int socket;
}

class ParticipantsInfo : PacketHeader
{
    //int page;
    public int count;
    public int arraySize;

    public List<userInformation> BelongInfos;
};

class CreatedRoomList : PacketHeader
{
    //int page;
    public int count = 0;
    public int arraySize;
    
    public List<SendingRoomStruct> roomList;
};

class userInformation
{
    public int socket;

    public int userID;
    public int roomNum;
    public ushort nameSize;

    public string name;

    public bool isReady;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class UserData : PacketHeader
{
    public int userID;
    public int roomNum;
    public ushort nameSize;

    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
    public string name;
};

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class SendChatting : PacketHeader
{
    public ushort nameSize;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
    public string name;

    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 255)]
    public string message;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class CreateRoom : PacketHeader
{
    public ushort roomNum;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class DestroyRoom : PacketHeader
{
    public ushort roomNum;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class JoinRoom : PacketHeader
{
    public ushort roomNum;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class IsReady : PacketHeader
{
    public bool isReady;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class ReqUserListData : PacketHeader
{
    public int page;
};

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class ReqRoomListData : PacketHeader
{
    public int page;
};

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class GomokuGrid : PacketHeader
{
    public int px;
    public int py;
    public bool isBlack;
};

[StructLayout(LayoutKind.Sequential, Pack = 1)]
class GomokuResult : PacketHeader
{
    public bool isBlack;
};