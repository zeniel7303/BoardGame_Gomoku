﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResultWindow : MonoBehaviour {

	//public Button ReplayButton;
    public Button Button;
    public Text Message;
	public MainLoop mainLoop;

	void Start () {
        //ReplayButton.onClick.AddListener(()=>{
        //	gameObject.SetActive(false);
        //	mainLoop.Restart();
        //  });

        Button.onClick.AddListener(() => {
            GameManager.Instance.ExitRoom();
        });
	}

    void Update()
    {
        if (GameManager.Instance.RecvExitSuccess)
        {
            GameManager.Instance.RecvExitSuccess = false;

            GameManager.Instance.user.isReady = false;

            GameManager.Instance.goLobby = true;
        }
    }

    public void Show (ChessType wintype) {
        switch (wintype) {
			case ChessType.Black:
                {
                    Message.text = string.Format("BLACK WIN!");
				}
				break;
			case ChessType.White:
				{
					Message.text = string.Format("WHITE WIN!");
				}
				break;
		}
	}
}
