﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainLoop : MonoBehaviour {

    public GameObject WhitePrefab;
    public GameObject BlackPrefab;

    public GameObject BlackTurn;
    public GameObject WhiteTurn;

    public ResultWindow ResultWindow;

    enum myColor
    {
        Black,
        White
    }

    enum State
    {
        BlackGo, 
        WhiteGo, 
        Over,    
    }

    State _state;
    myColor _color;

    Board _board;

    BoardModel _model;

    bool CanPlace( int gridX, int gridY )
    {
        return _model.Get(gridX, gridY) == ChessType.None;        
    }

    bool PlaceChess(Cross cross, bool isblack)
    {
        if (cross == null)
            return false;

        var newChess = GameObject.Instantiate<GameObject>(isblack ? BlackPrefab : WhitePrefab);
        newChess.transform.SetParent(cross.gameObject.transform, false);

        _model.Set(cross.GridX, cross.GridY, isblack ? ChessType.Black : ChessType.White);

        var ctype = isblack ? ChessType.Black : ChessType.White;

        var linkCount = _model.CheckLink(cross.GridX, cross.GridY, ctype);

        return linkCount >= BoardModel.WinChessCount;
    }

    public void Restart( )
    {
        if(GameManager.Instance.user.isBlack)
        {
            _color = myColor.Black;
        }
        else
        {
            _color = myColor.White;
        }

        _state = State.BlackGo;
        _model = new BoardModel();
        _board.Reset();
    }

    public void OnClick( Cross cross )
    {
        if(_color == myColor.Black)
        {
            if (_state != State.BlackGo)
                return;

            if (CanPlace(cross.GridX, cross.GridY))
            {
                GameManager.Instance.SendGomokuGrid(cross.GridX, cross.GridY);

                if (PlaceChess(cross, true))
                {
                    _state = State.Over;
                    //GameManager.Instance.SendGomokuResult();
                    ShowResult(ChessType.Black);
                }
                else
                {
                    _state = State.WhiteGo;
                }
            }
        }
        else if(_color == myColor.White)
        {
            if (_state != State.WhiteGo)
                return;

            if (CanPlace(cross.GridX, cross.GridY))
            {
                GameManager.Instance.SendGomokuGrid(cross.GridX, cross.GridY);

                if (PlaceChess(cross, false))
                {
                    _state = State.Over;
                    //GameManager.Instance.SendGomokuResult();
                    ShowResult(ChessType.White);
                }
                else
                {
                    _state = State.BlackGo;
                }
            }
        }
    }

    void Start( )
    {
        _board = GetComponent<Board>();

        Restart();
    }

    int _lastPlayerX, _lastPlayerY;

    void ShowResult( ChessType winside )
    {
        ResultWindow.gameObject.SetActive(true);
        ResultWindow.Show(winside);
    }

	// Update is called once per frame
	void Update ()
    {
        if(_state == State.BlackGo)
        {
            BlackTurn.SetActive(true);
            WhiteTurn.SetActive(false);
        }
        else if (_state == State.WhiteGo)
        {
            BlackTurn.SetActive(false);
            WhiteTurn.SetActive(true);
        }

        if(GameManager.Instance.ptx != 0 && GameManager.Instance.pty != 0)
        {
            if(GameManager.Instance.isBlackStone)
            {
                if(PlaceChess(_board.GetCross(GameManager.Instance.ptx, GameManager.Instance.pty), 
                   true))
                {
                    _state = State.Over;
                    ShowResult(ChessType.Black);
                }
                else
                {
                    _state = State.WhiteGo;
                }
            }
            else
            {
                if (PlaceChess(_board.GetCross(GameManager.Instance.ptx, GameManager.Instance.pty),
                   false))
                {
                    _state = State.Over;
                    ShowResult(ChessType.White);
                }
                else
                {
                    _state = State.BlackGo;
                }
            }

            GameManager.Instance.ptx = 0;
            GameManager.Instance.pty = 0;
        }
    }
}
