﻿//atlusing System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text;

public class LobbyManager : MonoBehaviour
{
    public UserInfoUI userInfoUIPrefabs;
    public RectTransform userInfoZone;

    public List<UserInfoUI> userInfoList;

    public RoomInfoUI roomInfoPrefabs;
    public RectTransform roomInfoZone;

    //표시되는 룸관련 ui
    public List<RoomInfoUI> roomInfoList;
    private RoomInfoUI[] roomArray = new RoomInfoUI[12];

    [SerializeField]
    private List<Room> roomList = new List<Room>();
    [SerializeField]
    private List<User> userList = new List<User>();

    public GameObject lobbyCanvas, roomCanvas;
    public RoomPlayerInfo roomPlayerInfo_1, roomPlayerInfo_2;

    public int userListPage = 1;
    public int roomListPage = 1;

    public Text channelNum;

    private void Awake()
    {
        channelNum.text = string.Format("No.{0} Channel",
            GameManager.Instance.channelNum);

        for (int i = 0; i < 12; i++)
        {
            RoomInfoUI roomInfo = RoomInfoUI.Instantiate(roomInfoPrefabs);
            roomInfo.transform.SetParent(roomInfoZone);
            roomInfo.transform.localScale = Vector3.one;

            roomInfo.InitRoom();

            roomInfo.lobbyManager = this;

            roomInfoList.Add(roomInfo);
        }

        for (int i = 0; i < 12; i++)
        {
            roomInfoList[i].gameObject.SetActive(false);
        }

        for (int i = 0; i < 100; i ++)
        {
            UserInfoUI curUserUI = UserInfoUI.Instantiate(userInfoUIPrefabs);

            User curUser = new User();
            curUser.Init("");

            curUserUI.SetUserInfo(curUser);
            curUserUI.transform.SetParent(userInfoZone);
            curUserUI.transform.localScale = Vector3.one;

            userInfoList.Add(curUserUI);
        }

        for(int i = 0; i < 100; i ++)
        {
            userInfoList[i].gameObject.SetActive(false);
        }

        GameManager.Instance.user.userState = EUserState.Lobby;

        GoLobby();
    }

    void Update()
    {
        if (GameManager.Instance.RecvCreatedSuccess)
        {
            GameManager.Instance.RecvCreatedSuccess = false;

            GoRoom();
        }

        if (GameManager.Instance.RecvExitSuccess)
        {
            GameManager.Instance.RecvExitSuccess = false;

            GameManager.Instance.user.isReady = false;

            GoLobby();
        }

        if(GameManager.Instance.RecvEnterSuccess)
        {
            GameManager.Instance.RecvEnterSuccess = false;

            GoRoom();
        }

        UserInfoUpdate();

        RoomListUpdate();
    }

    public void RoomListUpdate()
    {
        if (GameManager.Instance.user.userState == EUserState.Lobby)
        {
            int tempNum = 0;
            for(int i = 0; i < roomInfoList.Count; i++)
            {
                if(roomInfoList[i].gameObject.activeSelf == true)
                {
                    tempNum++;
                }
            }

            if (tempNum > GameManager.Instance.GetCreatedRoomsCount())
            {
                for (int i = GameManager.Instance.GetCreatedRoomsCount(); i < tempNum; i++)
                {
                    roomInfoList[i].gameObject.SetActive(false);
                }
            }
            else if (tempNum < GameManager.Instance.GetCreatedRoomsCount())
            {
                for (int i = tempNum; i < GameManager.Instance.GetCreatedRoomsCount(); i++)
                {
                    roomInfoList[i].gameObject.SetActive(true);
                }
            }

            for (int i = 0; i < GameManager.Instance.GetCreatedRoomsCount(); i++)
            {
                roomInfoList[i].roomInfo.index = GameManager.Instance.GetCreatedRoomIndex(i);
                roomInfoList[i].roomInfo.nowUserCount = GameManager.Instance.GetCreatedRoomCount(i);
                roomInfoList[i].roomInfo.maxUserCount = GameManager.Instance.GetCreatedRoomComplement(i);
                roomInfoList[i].roomInfo.isPlaying = GameManager.Instance.GetCreatedRoomIsPlaying(i);

                roomInfoList[i].ReleaseDisplay();
            }
        }
    }

    public void UserInfoUpdate()
    {
        if (GameManager.Instance.user.userState == EUserState.Lobby)
        {
            int tempNum = 0;
            for (int i = 0; i < userInfoList.Count; i++)
            {
                if (userInfoList[i].gameObject.activeSelf == true)
                {
                    tempNum++;
                }
            }

            if (tempNum > GameManager.Instance.GetParticipantsCount())
            {
                for (int i = GameManager.Instance.GetParticipantsCount(); i < tempNum; i++)
                {
                    userInfoList[i].gameObject.SetActive(false);
                }
            }
            else if (tempNum < GameManager.Instance.GetParticipantsCount())
            {
                for (int i = tempNum; i < GameManager.Instance.GetParticipantsCount(); i++)
                {
                    userInfoList[i].gameObject.SetActive(true);
                }
            }

            for (int i = 0; i < GameManager.Instance.GetParticipantsCount(); i++)
            {
                userInfoList[i].userText.text = GameManager.Instance.GetParticipantName(i);
            }
        }
        else if (GameManager.Instance.user.userState == EUserState.Room)
        {
            int tempNum = 0;
            for(int i = 0; i < GameManager.Instance.GetParticipantsCount(); i++)
            {
                tempNum++;
            }

            if (GameManager.Instance.GetParticipantsCount() == 1)
            {
                Debug.Log("룸 유저1 정보 갱신");
                roomPlayerInfo_1.SetPlayerName(GameManager.Instance.GetParticipantName(0));
                roomPlayerInfo_1.SetReady(GameManager.Instance.GetParticipantIsReady(0));

                if (roomPlayerInfo_2.playerName.text != "빈 자리")
                {
                    roomPlayerInfo_2.ResetAll();
                }
            }
            else if(GameManager.Instance.GetParticipantsCount() == 2)
            {
                roomPlayerInfo_1.SetPlayerName(GameManager.Instance.GetParticipantName(0));
                roomPlayerInfo_2.SetPlayerName(GameManager.Instance.GetParticipantName(1));

                roomPlayerInfo_1.SetReady(GameManager.Instance.GetParticipantIsReady(0));
                roomPlayerInfo_2.SetReady(GameManager.Instance.GetParticipantIsReady(1));
            }
        }
    }

    //룸생성
    public void CreateRoom()
    {
        GameManager.Instance.CreateRoom();
    }

    //빠른 입장
    public void FastEnterRoom()
    {
        //for (int i = 0; i < roomList.Count; i++)
        //{
        //    if (!roomList[i].IsFull())
        //    {
        //        GameManager.Instance.user.SetRoom(roomList[i].index);

        //        roomList[i].SetUser(GameManager.Instance.user);

        //        DeleteUserInfoList(GameManager.Instance.user);

        //        GoRoom();

        //        return;
        //    }
        //}
    }

    //해당 방 입장
    public void EnterRoom(Room _room)
    {
        GameManager.Instance.EnterRoom(_room.index);
    }

    //방 나가기
    public void ExitRoom()
    {
        GameManager.Instance.ExitRoom();
    }

    public void ReadyGame()
    {
        GameManager.Instance.Ready();
    }

    public void GoLobby()
    {
        lobbyCanvas.gameObject.SetActive(true);
        roomCanvas.gameObject.SetActive(false);

        GameManager.Instance.user.userState = EUserState.Lobby;
    }

    public void GoRoom()
    {
        lobbyCanvas.gameObject.SetActive(false);
        roomCanvas.gameObject.SetActive(true);

        GameManager.Instance.user.userState = EUserState.Room;
    }

    public void RefreshUserList()
    {
        GameManager.Instance.ReqRefreshLobbyUserList(userListPage);
    }

    public void SetUserListPage1()
    {
        userListPage = 1;
    }
    public void SetUserListPage2()
    {
        userListPage = 2;
    }
    public void SetUserListPage3()
    {
        userListPage = 3;
    }
    public void SetUserListPage4()
    {
        userListPage = 4;
    }
    public void SetUserListPage5()
    {
        userListPage = 5;
    }

    public void RefreshRoomList()
    {
        GameManager.Instance.ReqRefreshRoomList(roomListPage);
    }

    public void SetRoomListPage1()
    {
        roomListPage = 1;
        this.RefreshRoomList();
    }
    public void SetRoomListPage2()
    {
        roomListPage = 2;
        this.RefreshRoomList();
    }
    public void SetRoomListPage3()
    {
        roomListPage = 3;
        this.RefreshRoomList();
    }
    public void SetRoomListPage4()
    {
        roomListPage = 4;
        this.RefreshRoomList();
    }
    public void SetRoomListPage5()
    {
        roomListPage = 5;
        this.RefreshRoomList();
    }
}
