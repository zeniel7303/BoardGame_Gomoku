﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChattingManager : MonoBehaviour
{
    private CircleQueue<string> chattedUserQueue;
    private CircleQueue<string> chattingQueue;

    public ChattingInputField inputField;

    //나중에 오브젝트 풀로
    private Text[] textArray;

    public RectTransform chattingZone;

    public Text textPrefabs;

    public int maxChattingSize;

    private int nowChattingCount;

    //protected override void Awake()
    void Awake()
    {
        chattedUserQueue = new CircleQueue<string>();
        chattedUserQueue.Init(maxChattingSize, "");

        chattingQueue = new CircleQueue<string>();
        chattingQueue.Init(maxChattingSize, "");

        textArray = new Text[maxChattingSize];

        for (int i = 0; i < maxChattingSize; i++)
        {
            textArray[i] = Text.Instantiate(textPrefabs);
            textArray[i].transform.SetParent(chattingZone);
            textArray[i].transform.localScale = Vector3.one;
            textArray[i].text = "";
        }

        chattingZone.localPosition = new Vector3(0, 34);

        nowChattingCount = 0;

        inputField.SetOnEndEdit(ChattingInput);
    }

    void Update()
    {
        if(GameManager.Instance.tempUser != null &&
            GameManager.Instance.tempChatting != null)
        {
            chattedUserQueue.Enqueue(GameManager.Instance.tempUser);
            chattingQueue.Enqueue(GameManager.Instance.tempChatting);

            ShowChatting();

            nowChattingCount++;

            if (nowChattingCount >= 10)
            {
                chattingZone.localPosition = new Vector3(0, (nowChattingCount - 10) * 34 + 34);
            }

            GameManager.Instance.tempUser = null;
            GameManager.Instance.tempChatting = null;
        }
    }

    public void ChattingInput(string _value)
    {
        if (_value == "")
            return;

        GameManager.Instance.session.SendMessage(_value);
    }

    public void ShowChatting()
    {
        for (int i = 0; i < maxChattingSize; i++)
        {
            if (chattedUserQueue.GetQueueParameter(i) == "")
                continue;

            if (chattingQueue.GetQueueParameter(i) == "")
                continue;

            textArray[i].text = string.Format("{0} : {1}",
                chattedUserQueue.GetQueueParameter(i),
                chattingQueue.GetQueueParameter(i));
        }
    }
}
