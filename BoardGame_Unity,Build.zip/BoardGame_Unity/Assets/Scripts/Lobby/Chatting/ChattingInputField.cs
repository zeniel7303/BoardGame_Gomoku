﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ChattingInputField : InputField
{
    protected override void Awake()
    {
      //  onEndEdit.AddListener(ChattingManager.Instance.ChattingInput);
        onEndEdit.AddListener(EndEnter);
    }

    public void SetOnEndEdit(UnityEngine.Events.UnityAction<string> call)
    {
        onEndEdit.AddListener(call);
    }

    public void EndEnter(string _value)
    {
        this.Select();
        this.ActivateInputField();
        m_Text = "";
    }
}
