﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Runtime.InteropServices;

public enum EUserState
{
    Login, Lobby, Room
}

[System.Serializable]
public class User
{
    [SerializeField]
    public string userName;
    public int roomIndex;
    public EUserState userState;

    public bool isReady = false;
    public bool isBlack = false;

    public void Init(string _userName)
    {
        userName = _userName;
    }

    public string GetUserName()
    {
        return userName;
    }

    public int GetRoom()
    {
        return roomIndex;
    }

    public void SetRoom(int _roomIndex)
    {
        roomIndex = _roomIndex;
    }
}

public class UserInfoUI : MonoBehaviour
{
    private User info;

    public Text userText;

    public void SetUserInfo(string _userName)
    {
        info = new User();
        info.Init(_userName);

        userText.text = info.GetUserName();
    }

    public void SetUserInfo(User _user)
    {
        info = _user;

        userText.text = info.GetUserName();
    }
}

