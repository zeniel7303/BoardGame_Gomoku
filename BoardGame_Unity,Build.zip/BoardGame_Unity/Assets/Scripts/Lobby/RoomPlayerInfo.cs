﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RoomPlayerInfo : MonoBehaviour
{
    public Text playerName;
    public GameObject ready;
    bool isReady;

    // Start is called before the first frame update
    void Start()
    {
        playerName.text = "Empty";

        ready.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SetPlayerName(string str)
    {
        playerName.text = str;
    }

    public void SetReady(bool value)
    {
        if(value)
        {
            ready.SetActive(true);
            isReady = true;
        }
        else
        {
            ready.SetActive(false);
            isReady = false;
        }
    }

    public bool GetReady()
    {
        return isReady;
    }

    public void ResetAll()
    {
        playerName.text = "Empty";

        ready.SetActive(false);
    }
}
