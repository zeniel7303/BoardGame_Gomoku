﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Runtime.InteropServices;

[System.Serializable]
public class Room
{
    public int index;

    public string roomName;
    
    public int nowUserCount;
    public int maxUserCount;

    public bool isPlaying;

    public void Init()
    {
        maxUserCount = 2;
        nowUserCount = 0;
        index = 0;
        roomName = "";
    }
}

public class RoomInfoUI : MonoBehaviour
{
    public Text roomText;
    public Text roomUserCountText;
    public Text roomIsPlaying;

    public Room roomInfo;

    private Button button;

    [HideInInspector]
    public LobbyManager lobbyManager;

    public void Awake()
    {
        button = this.GetComponent<Button>();

        button.onClick.AddListener(EnterRoom);
    }

    public void InitRoom()
    {
        roomText.text = "";

        roomUserCountText.text = "";
    }

    public void EnterRoom()
    {
        if (roomInfo == null ||
            roomInfo.index == 0)
            return;

        lobbyManager.EnterRoom(this.roomInfo);
    }

    public void ReleaseDisplay()
    {
        roomText.text = string.Format("No.{0} Room",
            roomInfo.index);

        roomUserCountText.text = string.Format("{0} / {1}",
            roomInfo.nowUserCount, roomInfo.maxUserCount);

        if (roomInfo.isPlaying)
        {
            roomIsPlaying.gameObject.SetActive(true);
        }
        else
        {
            roomIsPlaying.gameObject.SetActive(false);
        }
    }
}
