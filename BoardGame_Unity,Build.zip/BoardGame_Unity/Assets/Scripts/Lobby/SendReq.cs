﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SendReq : MonoBehaviour
{
    public LobbyManager lobbyManager;

    float timer1;
    float waitingTime1;

    float timer2;
    float waitingTime2;

    // Start is called before the first frame update
    void Start()
    {
        timer1 = 0.0f;
        waitingTime1 = 0.5f;

        timer2 = 0.0f;
        waitingTime2 = 0.5f;
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.Instance.user.userState == EUserState.Lobby)
        {
            if (timer1 > waitingTime1)
            {
                if(timer2 == 0)
                {
                    Debug.Log("로비 유저 리스트 요청");
                    GameManager.Instance.ReqRefreshLobbyUserList(lobbyManager.userListPage);
                }
               
                timer2 += Time.deltaTime;
            }
            else
            {
                timer1 += Time.deltaTime;
            }

            if(timer2 > waitingTime2)
            {
                Debug.Log("룸 리스트 요청");
                GameManager.Instance.ReqRefreshRoomList(lobbyManager.roomListPage);

                timer1 = 0;
                timer2 = 0;
            }
        }
    }
}
