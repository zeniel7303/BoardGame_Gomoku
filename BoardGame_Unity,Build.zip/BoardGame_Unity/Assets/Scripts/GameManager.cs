﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;
using System.Threading;
using System.Text;

public class GameManager : Singleton<GameManager>
{
    private Thread thread = null;
    private object lockObject = new object();       // 임계영역 처리를 위한 오브젝트 생성

    private int recvByte = 0;
    private byte[] recvData = new byte[1000];
    private byte[] buffer = new byte[100000];
    private int bufferEndCheck = 0;
    private int bufferSize = 0;

    public User user;
    public Session session;
    public int channelNum = 0;

    public bool goLobby = false;
    bool goGame = false;

    public ushort tempWord;
    public string tempUser;
    public string tempChatting = null;

    ParticipantsInfo participantsInfo = new ParticipantsInfo();
    CreatedRoomList createdRoomInfo = new CreatedRoomList();

    public bool RecvCreatedSuccess = false;
    public bool RecvExitSuccess = false;
    public bool RecvEnterSuccess = false;

    public bool isBlackStone;
    public int ptx;
    public int pty;

    public bool isBlackWin;
    public bool isGetResult = false;

    protected override void Awake()
    {
        base.Awake();

        session = new Session();

        user.userState = EUserState.Login;

        ptx = 0;
        pty = 0;
    }

    void Update()
    {
        if(goLobby)
        {
            //SceneManager.LoadScene("Lobby");
            SceneManager.LoadScene("Lobby_2");
            goLobby = false;
        }

        if(goGame)
        {
            SceneManager.LoadScene("Gomoku");
            goGame = false;
        }

        if (Input.GetKeyDown(KeyCode.Return) &&
            user.GetUserName().Length > 0 &&
            user.userState == EUserState.Login)
        {
            ConnectUser();
        }
    }

    public void SetUserName(string _name)
    {
        user.Init(_name);
    }

    public void Channel1_ConnectUser()
    {
        if (user.GetUserName().Length > 0)
        {
            session.Init("211.34.59.107", 30002);
            //session.Init("127.0.0.1", 30002);
            //session.Init("210.124.208.78", 30002);

            if (thread == null)
            {
                thread = new Thread(RunThread);
                thread.Start();
            }

            channelNum = 1;
        }
    }

    public void Channel2_ConnectUser()
    {
        if (user.GetUserName().Length > 0)
        {
            session.Init("211.34.59.107", 30003);
            //session.Init("127.0.0.1", 30003);

            if (thread == null)
            {
                thread = new Thread(RunThread);
                thread.Start();
            }

            channelNum = 2;
        }
    }

    public void Channel3_ConnectUser()
    {
        if (user.GetUserName().Length > 0)
        {
            session.Init("211.34.59.107", 30004);
            //session.Init("127.0.0.1", 30004);

            if (thread == null)
            {
                thread = new Thread(RunThread);
                thread.Start();
            }

            channelNum = 3;
        }
    }

    public void ConnectUser()
    {
        if (user.GetUserName().Length > 0)
        {
            session.Init("127.0.0.1", 30002);

            if (thread == null)
            {
                thread = new Thread(RunThread);
                thread.Start();
            }
        }    
    }

    public void CreateRoom()
    {
        session.SendCreateRoom();
    }

    public void ExitRoom()
    {
        session.SendExitRoom();
    }

    public void EnterRoom(int roomNum)
    {
        session.SendJoinRoom(roomNum);
    }

    public void Ready()
    {
        if(user.isReady)
        {
            session.SendReady(false);
        }
        else
        {
            session.SendReady(true);
        }
    }

    public void ReqRefreshLobbyUserList(int pageNum)
    {
        session.SendReqLobbyUserList(pageNum);
    }

    public void ReqRefreshRoomList(int pageNum)
    {
        session.SendReqRoomList(pageNum);
    }

    public void SendGomokuGrid(int x, int y)
    {
        session.SendGomokuGrid(x, y, user.isBlack);
    }

    public void SendGomokuResult()
    {
        session.SendGomokuResult(user.isBlack);
    }

    //Get부분들
    public int GetParticipantsCount()
    {
        return participantsInfo.BelongInfos.Count;
    }

    public string GetParticipantName(int num)
    {
        return participantsInfo.BelongInfos[num].name;
    }

    public bool GetParticipantIsReady(int num)
    {
        return participantsInfo.BelongInfos[num].isReady;
    }

    public int GetCreatedRoomsCount()
    {
        return createdRoomInfo.count;
    }

    public int GetCreatedRoomIndex(int num)
    {
        return createdRoomInfo.roomList[num].index;
    }

    public int GetCreatedRoomCount(int num)
    {
        return createdRoomInfo.roomList[num].count;
    }

    public int GetCreatedRoomComplement(int num)
    {
        return createdRoomInfo.roomList[num].complement;
    }

    public bool GetCreatedRoomIsPlaying(int num)
    {
        return createdRoomInfo.roomList[num].isPlaying;
    }

    //쓰레드
    void RunThread()
    {
        ushort packetSize = 0;
        ushort cmd = 0;

        while (true)
        {
            Thread.Sleep(0);

            //Debug.Log("쓰레드 시작됨");

            recvByte = session.mySocket.Receive(recvData);

            if(recvByte <= 0)
            {
                //Debug.Log("쓰레드 종료됨");

                //쓰레드 강제 종료
                thread.Interrupt();
                thread.Abort();

                return;
            }

            bufferSize += recvByte;

            Buffer.BlockCopy(recvData, 0, buffer, bufferEndCheck, recvByte);

            if(bufferSize < 2)
            {
                bufferEndCheck += recvByte;

                return;
            }

            packetSize = BitConverter.ToUInt16(recvData, 0);

            if(bufferSize < packetSize)
            {
                bufferEndCheck += recvByte;

                return;
            }

            cmd = BitConverter.ToUInt16(recvData, 2);

            switch (cmd)
            {
                case 88:
                    session.FailConnect();
                    break;
                case 89:
                    goLobby = true;
                    break;
                case 90:
                    session.RecvUserInfo(recvData, user.userName);
                    break;
                case 91:
                    tempWord = (ushort)BitConverter.ToInt32(recvData, 8);
                    tempUser = Encoding.Default.GetString(recvData, 10, tempWord).Trim('\0');
                    tempChatting = Encoding.Default.GetString(recvData, 42, 296);
                    break;
                case 92:
                    if (session.RecvCreateRoom(recvData)) RecvCreatedSuccess = true;
                    break;
                case 93:
                    if (session.RecvExitRoom(recvData)) RecvExitSuccess = true;
                    break;
                case 94:
                    if (session.RecvJoinRoom(recvData)) RecvEnterSuccess = true;
                    break;
                case 95:
                    List<userInformation> tempUserList = new List<userInformation>();

                    //8, 9, 10, 11
                    participantsInfo.count = BitConverter.ToInt32(recvData, 8);
                    //11, 12, 13, 14
                    participantsInfo.arraySize = BitConverter.ToInt32(recvData, 12);

                    for (int i = 0; i < participantsInfo.count; i++)
                    {
                        userInformation tempInfo = new userInformation();
                        int tempSize = participantsInfo.arraySize / participantsInfo.count;

                        tempInfo.nameSize = (ushort)BitConverter.ToInt32(recvData,
                            28 + (tempSize * i));
                        tempInfo.name = Encoding.Default.GetString(recvData, 30 + (tempSize * i),
                             tempInfo.nameSize);
                        tempInfo.isReady = BitConverter.ToBoolean(recvData, 62 + (tempSize * i));

                        tempUserList.Add(tempInfo);
                    }

                    participantsInfo.BelongInfos = tempUserList;
                    break;
                case 96:
                    List<SendingRoomStruct> tempRoomList = new List<SendingRoomStruct>();

                    createdRoomInfo.count = BitConverter.ToInt32(recvData, 8);
                    createdRoomInfo.arraySize = BitConverter.ToInt32(recvData, 12);

                    for (int i = 0; i < createdRoomInfo.count; i++)
                    {
                        SendingRoomStruct tempRoomStruct = new SendingRoomStruct();

                        int tempSize = createdRoomInfo.arraySize / createdRoomInfo.count;

                        tempRoomStruct.isPlaying = BitConverter.ToBoolean(recvData, 16 + (tempSize * i));
                        tempRoomStruct.index = BitConverter.ToInt32(recvData, 17 + (tempSize * i));
                        tempRoomStruct.count = BitConverter.ToInt32(recvData, 21 + (tempSize * i));
                        tempRoomStruct.complement = BitConverter.ToInt32(recvData, 25 + (tempSize * i));

                        tempRoomList.Add(tempRoomStruct);
                    }

                    createdRoomInfo.roomList = tempRoomList;
                    break;
                case 97:
                    user.isReady = BitConverter.ToBoolean(recvData, 8);
                    break;
                case 198:
                    goGame = true;
                    user.isBlack = true;
                    break;
                case 199:
                    goGame = true;
                    user.isBlack = false;
                    break;
                case 200:
                    session.RecvGomokuGrid(recvData);

                    isBlackStone = session.isBlackStone;
                    ptx = session.ptx;
                    pty = session.pty;
                    break;
                case 201:
                    session.RecvGomokuResult(recvData);

                    isBlackWin = session.isBlackWin;
                    isGetResult = true;
                    break;
            }
        }
    }
}
