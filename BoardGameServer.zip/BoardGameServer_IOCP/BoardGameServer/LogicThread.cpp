#include "LogicThread.h"

LogicThread::LogicThread()
{
	Start(this);
}

LogicThread::~LogicThread()
{
}

void LogicThread::Init()
{

}

void LogicThread::LoopRun()
{
	while (1)
	{

	}
}